# Mini Task Tracker

A minimal Flutter demo app for tracking simple tasks. Built with Material 3.

## Features

- View a list of tasks with their status (`Pending` / `Complete`)
- Add a new task from a small set of presets
- Tap a task to view its details
- Update a task's status from the detail screen

## Project structure

```
mini_task_tracker/
├── lib/
│   └── main.dart      # App entry point and all screens/widgets
├── pubspec.yaml        # Dependencies and project metadata
├── analysis_options.yaml
└── .gitignore
```

## Getting started

### Prerequisites

- [Flutter SDK](https://docs.flutter.dev/get-started/install) (3.0.0 or newer)
- A connected device, simulator/emulator, or a supported desktop/web target

### Run locally

```bash
flutter pub get
flutter run
```

### Generate platform folders (if needed)

This repo only includes the `lib/` source and project config. If you want to
run on a specific platform (Android, iOS, web, desktop) and the platform
folder isn't present yet, generate it with:

```bash
flutter create .
```

This scaffolds the platform-specific directories (`android/`, `ios/`, `web/`,
etc.) around the existing `lib/` and `pubspec.yaml` without overwriting them.

## Screens

| Screen | Description |
|---|---|
| `HomeScreen` | Lists all tasks with status indicators |
| `AddTaskScreen` | Pick a preset task to add to the list |
| `TaskDetailScreen` | View a single task's details |
| `MarkStatusScreen` | Mark a task Complete or Pending |

## License

This project has no license specified — add one (e.g. MIT) if you plan to share it publicly.
